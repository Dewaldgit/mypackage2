# mypackage2

This package was used as a second example on how to publish your own python package.

## building this package locally

"python setup.py sdist"

## Usage

top_n(items) returns a list in descending order.

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
DJ

## Installing this package from Github
"pip install git+https://"

## Updating this package from GitHub
"pip install --upgrade git+https://"
